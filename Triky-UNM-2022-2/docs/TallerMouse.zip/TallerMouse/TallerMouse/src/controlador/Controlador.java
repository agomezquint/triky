package controlador;

import java.lang.*;

// Importar el paquete del mundo y de la interfaz.

public class Controlador
{   
 // Atributos controlables de la interfaz. 	    
 
    
 // Atributo del mundo.

	
	
 // Constructor	
	public Controlador()
	{ // Instanciar la clase principal del modelo.
	     
	}
	
 // Recibe las referencias de los objetos a controlar en la interfaz	
	public void conectar(  )
	{ 
	}


	
 // --------------------------------------------------------------	
 // Implementacion de los requerimientos de usuario.	
 // --------------------------------------------------------------

    public void humanPlayed(int x, int y)
    { System.out.println("ctrl - Jug� el humano...");
    	
    }
	
	
    public void machinePlays()
    { System.out.println("ctrl - Juega la maquina...");
    	
    }
}