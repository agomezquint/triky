package interfaz;

import java.awt.Color;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;

import controlador.Controlador;
import win.Win;

public class InterfazApp extends JFrame
{
 // Constantes
	private static final String TRIKY     = "imagenes/triky.jpg";
	 
 // Atributos de instancia
    private ImageIcon imgTriky;
    private JLabel lblTriky, lblGame[][];
    
 // Atributo de tipo Controlador   
    private Controlador ctrl;
    
 // Constructor
    public InterfazApp( Controlador ctrl ) 
    { setTitle( "Triky." );  
   	  getContentPane( ).setLayout( null );
   	
   // Integra el Controlador. 
   	  this.ctrl = ctrl;
   	  
   // Instancia los paneles  
   	  lblGame      = new JLabel[3][3];
      imgTriky     = new ImageIcon( TRIKY );
      lblTriky     = new JLabel();
      lblTriky.setIcon( imgTriky );
      
      
   // Instancia los label de la matriz de juego      
      int x = 7, y = 7, width = 50, botton = 50;
      for(int i=0;i<3;i++)
      { for(int j=0;j<3;j++)
   	    { lblGame[i][j] = new JLabel( "" );
   	   // lblGame[i][j].setBorder( new CompoundBorder( new EmptyBorder( 0, 0, 0, 0 ), new TitledBorder( "" ) ) );
   	      lblGame[i][j].setHorizontalAlignment( JLabel.CENTER );
   	      lblGame[i][j].setVerticalAlignment( JLabel.CENTER );
   	      lblGame[i][j].setEnabled( true );
   	      lblGame[i][j].setBounds(x, y, width, botton);
   	      x += 65;
   	      lblGame[i][j].addMouseListener( new LabelClicMouse( i, j, lblGame[i][j], this.ctrl ) );
   	      add(lblGame[i][j]);
   	    }
        x = 7; y += 65;
      }       
      
      
   // Organizar el panel principal. 
      getContentPane( ).add( lblTriky );      
      lblTriky.setBounds(0, 0, 325, 190);   
      
   // Propiedades de la interfaz.   
      setSize( 335, 280 );      
      setResizable( false );
      setBackground(Color.WHITE);
      setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
   
  //  Conecta objetos al controlador.
      ctrl.conectar();
      
  //  Centrar ventana.
      Win.centrarVentana( this );
    }    
   
//  Ejecuci�n.		
    public static void main(String args[])
    { InterfazApp frmMain = new InterfazApp( new Controlador() );
      frmMain.setVisible( true );	  
    }
    
}

/**
 * Controlador de eventos del Mouse
 * @author Giovanni Fajardo Utria
 */
class LabelClicMouse extends MouseAdapter 
{// Constantes  
    private static final String OOOOO = "imagenes/O.png";
    private static final String EQUIS = "imagenes/X.png";
  
 // Atributos de clase
    private static boolean swClic;
    
 // Atributos de instancia   
    private JLabel label;
    private Controlador ctrl;
    private int x, y;
    private ImageIcon imgOoooo, imgEquis;
    
 // Constructor   
    public LabelClicMouse( int x, int y, JLabel label, Controlador ctrl )
    { this.label = label;
      this.ctrl = ctrl;
      this.x = x; this.y = y;
      this.swClic = false;
      this.imgOoooo = new ImageIcon( OOOOO );
      this.imgEquis = new ImageIcon( EQUIS );
    }	
   
    public void mouseClicked(MouseEvent evento)
    {
         if ( evento.isMetaDown() )  // boton derecho del raton - pone X / O
	      {    if ((label.getText()).equals( "" ) && label.getIcon() == null && !swClic )
	           {    label.setIcon( imgEquis ); swClic = true;
	           }
	           else
	           if (label.getIcon() != null && label.getIcon().equals(imgEquis))
	           {   label.setIcon( null ); swClic = false;
	           }      
	      }
	      else
	      if ( evento.isAltDown() )  // boton medio del raton
	      {
	      }
	      else
	      if ( evento.isControlDown() ) // Control + boton izquierdo
	      {    
	      }
	      else	         
	      if ( (label.getText()).equals( "" ) && label.getIcon() != null && label.getIcon().equals(imgEquis) ) // boton izquierdo del raton
	      {     label.removeMouseListener( label.getMouseListeners()[0] );  
	            ctrl.humanPlayed(x, y); ctrl.machinePlays(); swClic = false;
	      }
      
    }
}